<?php

require __DIR__ . '/vendor/autoload.php';

$elevator_start = new \classes\Controller();
$elevator_start->start();