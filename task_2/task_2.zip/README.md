# Second Home Work on Academy Binary-Studio

To check this home work need run in console "php elevator_start.php".
Used files:
 - elevator_start.php
 - /classes/elevator.php
 - /classes/controller.php